#!/bin/bash
#########################################################################
#
# Name:     Load
# Purpose:  Load nvme driver 
##########################################################################

echo "make nvme_driver"
make

echo "Romove nvme_driver"
sudo rmmod nvme
sudo rmmod nvme_core

echo "Loading ut_nvme_driver"
sudo insmod nvme_core.ko
sudo insmod nvme.ko

echo "clean nvme_driver"
make clean

##########################################################################
# 
#END:  Load script 
#
#########################################################################




